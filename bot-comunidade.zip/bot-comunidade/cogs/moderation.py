"""Moderação manual: avisos, timeout, expulsão, banimento e casos."""
import datetime as dt

import discord
from discord import app_commands
from discord.ext import commands

from utils import (COLOR_BAD, COLOR_INFO, ConfirmView, guild_perm, hierarchy_error,
                   make_embed, parse_duration, record_case)

MOTIVO = "Motivo da ação (aparece nos logs)"


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.guild:
            return False
        if not await self.bot.module_enabled(interaction.guild_id, "moderation"):
            raise app_commands.CheckFailure("O módulo de moderação está desativado neste servidor.")
        return True

    @staticmethod
    async def _dm(user: discord.abc.User, text: str):
        """Aviso individual ao punido. Falhas (DM fechada) são ignoradas."""
        try:
            await user.send(text)
        except discord.HTTPException:
            pass

    async def _confirm(self, interaction, texto) -> bool:
        view = ConfirmView(interaction.user.id)
        await interaction.response.send_message(texto, view=view, ephemeral=True)
        await view.wait()
        return bool(view.value)

    # ---------- /aviso ----------
    @app_commands.command(name="aviso", description="Aplica um aviso a um membro")
    @app_commands.describe(membro="Membro a ser avisado", motivo=MOTIVO)
    @guild_perm(moderate_members=True)
    async def aviso(self, interaction: discord.Interaction, membro: discord.Member,
                    motivo: app_commands.Range[str, 1, 500]):
        if err := hierarchy_error(interaction.guild, interaction.user, membro):
            return await interaction.response.send_message(f"❌ {err}", ephemeral=True)
        n = await record_case(self.bot, interaction.guild, membro, interaction.user, "Aviso", motivo)
        total = len(await self.bot.db.get_cases(interaction.guild_id, membro.id, "Aviso", 100))
        await self._dm(membro, f"⚠️ Você recebeu um aviso em **{interaction.guild.name}**: {motivo}")
        await interaction.response.send_message(
            f"✅ Aviso aplicado a {membro.mention} (caso #{n}, {total} aviso(s) no total).")

    # ---------- /timeout ----------
    @app_commands.command(name="timeout", description="Silencia temporariamente um membro")
    @app_commands.describe(membro="Membro", duracao="Ex.: 10m, 2h, 1d (máx. 28d)", motivo=MOTIVO)
    @guild_perm(moderate_members=True)
    @app_commands.checks.bot_has_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, membro: discord.Member,
                      duracao: str, motivo: app_commands.Range[str, 1, 500]):
        if err := hierarchy_error(interaction.guild, interaction.user, membro):
            return await interaction.response.send_message(f"❌ {err}", ephemeral=True)
        delta = parse_duration(duracao)
        if not delta:
            return await interaction.response.send_message(
                "❌ Duração inválida. Use formatos como `30m`, `2h` ou `1d` (máx. 28d).", ephemeral=True)
        await membro.timeout(delta, reason=f"{interaction.user}: {motivo}")
        n = await record_case(self.bot, interaction.guild, membro, interaction.user,
                              "Timeout", motivo, f"Duração: {duracao}")
        await self._dm(membro, f"🔇 Você recebeu timeout de {duracao} em **{interaction.guild.name}**: {motivo}")
        await interaction.response.send_message(f"✅ {membro.mention} silenciado por {duracao} (caso #{n}).")

    @app_commands.command(name="untimeout", description="Remove o timeout de um membro")
    @guild_perm(moderate_members=True)
    @app_commands.checks.bot_has_permissions(moderate_members=True)
    async def untimeout(self, interaction: discord.Interaction, membro: discord.Member,
                        motivo: app_commands.Range[str, 1, 500] = "Não informado"):
        if err := hierarchy_error(interaction.guild, interaction.user, membro):
            return await interaction.response.send_message(f"❌ {err}", ephemeral=True)
        await membro.timeout(None, reason=f"{interaction.user}: {motivo}")
        n = await record_case(self.bot, interaction.guild, membro, interaction.user, "Untimeout", motivo)
        await interaction.response.send_message(f"✅ Timeout de {membro.mention} removido (caso #{n}).")

    # ---------- /expulsar ----------
    @app_commands.command(name="expulsar", description="Expulsa um membro do servidor")
    @guild_perm(kick_members=True)
    @app_commands.checks.bot_has_permissions(kick_members=True)
    async def expulsar(self, interaction: discord.Interaction, membro: discord.Member,
                       motivo: app_commands.Range[str, 1, 500]):
        if err := hierarchy_error(interaction.guild, interaction.user, membro):
            return await interaction.response.send_message(f"❌ {err}", ephemeral=True)
        if not await self._confirm(interaction, f"Expulsar **{membro}**?\nMotivo: {motivo}"):
            return
        await self._dm(membro, f"👢 Você foi expulso de **{interaction.guild.name}**: {motivo}")
        await membro.kick(reason=f"{interaction.user}: {motivo}")
        n = await record_case(self.bot, interaction.guild, membro, interaction.user, "Expulsão", motivo)
        await interaction.edit_original_response(content=f"✅ {membro} expulso (caso #{n}).", view=None)

    # ---------- /banir ----------
    @app_commands.command(name="banir", description="Bane um membro do servidor")
    @app_commands.describe(apagar_mensagens="Apagar mensagens dos últimos X dias (0-7)")
    @guild_perm(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def banir(self, interaction: discord.Interaction, membro: discord.Member,
                    motivo: app_commands.Range[str, 1, 500],
                    apagar_mensagens: app_commands.Range[int, 0, 7] = 0):
        if err := hierarchy_error(interaction.guild, interaction.user, membro):
            return await interaction.response.send_message(f"❌ {err}", ephemeral=True)
        if not await self._confirm(interaction, f"Banir **{membro}**?\nMotivo: {motivo}"):
            return
        await self._dm(membro, f"🔨 Você foi banido de **{interaction.guild.name}**: {motivo}")
        await interaction.guild.ban(membro, reason=f"{interaction.user}: {motivo}",
                                    delete_message_seconds=apagar_mensagens * 86400)
        n = await record_case(self.bot, interaction.guild, membro, interaction.user, "Banimento", motivo)
        await interaction.edit_original_response(content=f"✅ {membro} banido (caso #{n}).", view=None)

    @app_commands.command(name="desbanir", description="Remove o banimento de um usuário")
    @app_commands.describe(usuario_id="ID do usuário banido")
    @guild_perm(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def desbanir(self, interaction: discord.Interaction, usuario_id: str,
                       motivo: app_commands.Range[str, 1, 500] = "Não informado"):
        if not usuario_id.isdigit():
            return await interaction.response.send_message("❌ ID inválido.", ephemeral=True)
        user = discord.Object(int(usuario_id))
        try:
            await interaction.guild.unban(user, reason=f"{interaction.user}: {motivo}")
        except discord.NotFound:
            return await interaction.response.send_message("❌ Esse usuário não está banido.", ephemeral=True)
        n = await record_case(self.bot, interaction.guild, user, interaction.user, "Desbanimento", motivo)
        await interaction.response.send_message(f"✅ Usuário `{usuario_id}` desbanido (caso #{n}).")

    # ---------- consultas ----------
    @staticmethod
    def _fmt_case(c) -> str:
        data = c["created_at"][:16].replace("T", " ")
        return (f"**#{c['case_number']}** · {c['action']} · <@{c['moderator_id']}> · `{data}`\n"
                f"└ {c['reason'] or 'Sem motivo'}")

    @app_commands.command(name="historico", description="Mostra o histórico de casos de um usuário")
    @guild_perm(moderate_members=True)
    async def historico(self, interaction: discord.Interaction, usuario: discord.User):
        casos = await self.bot.db.get_cases(interaction.guild_id, usuario.id, limit=10)
        if not casos:
            return await interaction.response.send_message("Nenhum caso encontrado.", ephemeral=True)
        e = make_embed(f"Histórico de {usuario}", "\n".join(self._fmt_case(c) for c in casos), COLOR_INFO)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="caso", description="Consulta um caso pelo número")
    @guild_perm(moderate_members=True)
    async def caso(self, interaction: discord.Interaction, numero: int):
        c = await self.bot.db.get_case(interaction.guild_id, numero)
        if not c:
            return await interaction.response.send_message("Caso não encontrado.", ephemeral=True)
        e = make_embed(f"Caso #{numero}", self._fmt_case(c) + f"\nMembro: <@{c['user_id']}>")
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="limpar", description="Apaga mensagens recentes do canal")
    @app_commands.describe(quantidade="1 a 100 mensagens (com menos de 14 dias)")
    @guild_perm(manage_messages=True)
    @app_commands.checks.bot_has_permissions(manage_messages=True, read_message_history=True)
    async def limpar(self, interaction: discord.Interaction, quantidade: app_commands.Range[int, 1, 100]):
        await interaction.response.defer(ephemeral=True)
        apagadas = await interaction.channel.purge(limit=quantidade)
        e = make_embed("🧹 Limpeza de mensagens", color=COLOR_BAD)
        e.add_field(name="Canal", value=interaction.channel.mention)
        e.add_field(name="Responsável", value=interaction.user.mention)
        e.add_field(name="Quantidade", value=str(len(apagadas)))
        await self.bot.send_log(interaction.guild, e)
        await interaction.followup.send(f"✅ {len(apagadas)} mensagem(ns) apagada(s).", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Moderation(bot))
