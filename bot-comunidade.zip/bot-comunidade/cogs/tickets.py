"""Sistema de tickets com painel, assumir, encerrar e transcrição."""
import asyncio
import io
import re

import discord
from discord import app_commands
from discord.ext import commands

from utils import COLOR_INFO, ConfirmView, guild_perm, make_embed


async def is_staff(bot, member: discord.Member) -> bool:
    role_id = await bot.db.get_int(member.guild.id, "ticket_role")
    return member.guild_permissions.manage_channels or any(r.id == role_id for r in member.roles)


async def build_transcript(channel: discord.TextChannel) -> io.BytesIO:
    lines = [f"Transcrição de #{channel.name} — {channel.guild.name}", ""]
    async for m in channel.history(limit=5000, oldest_first=True):
        ts = m.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        lines.append(f"[{ts}] {m.author} ({m.author.id}): {m.clean_content}")
        for a in m.attachments:
            lines.append(f"    [anexo] {a.url}")
    return io.BytesIO("\n".join(lines).encode("utf-8"))


class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Assumir", emoji="🙋", style=discord.ButtonStyle.primary,
                       custom_id="ticket:claim")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot = interaction.client
        ticket = await bot.db.get_ticket_by_channel(interaction.channel_id)
        if not ticket:
            return await interaction.response.send_message("Ticket não encontrado.", ephemeral=True)
        if not await is_staff(bot, interaction.user):
            return await interaction.response.send_message(
                "❌ Apenas a equipe pode assumir tickets.", ephemeral=True)
        if ticket["claimed_by"]:
            return await interaction.response.send_message(
                f"Já assumido por <@{ticket['claimed_by']}>.", ephemeral=True)
        await bot.db.claim_ticket(ticket["id"], interaction.user.id)
        await interaction.response.send_message(
            f"🙋 {interaction.user.mention} assumiu este atendimento.",
            allowed_mentions=discord.AllowedMentions.none())

    @discord.ui.button(label="Encerrar", emoji="🔒", style=discord.ButtonStyle.danger,
                       custom_id="ticket:close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot = interaction.client
        channel = interaction.channel
        ticket = await bot.db.get_ticket_by_channel(channel.id)
        if not ticket:
            return await interaction.response.send_message("Ticket não encontrado.", ephemeral=True)
        if not (await is_staff(bot, interaction.user) or interaction.user.id == ticket["user_id"]):
            return await interaction.response.send_message(
                "❌ Você não pode encerrar este ticket.", ephemeral=True)

        view = ConfirmView(interaction.user.id)
        await interaction.response.send_message("Encerrar este atendimento?", view=view, ephemeral=True)
        await view.wait()
        if not view.value:
            return

        await bot.db.close_ticket(ticket["id"], interaction.user.id)
        transcript = await build_transcript(channel)
        filename = f"transcricao-{channel.name}.txt"

        log_id = (await bot.db.get_int(interaction.guild_id, "ticket_log_channel")
                  or await bot.db.get_int(interaction.guild_id, "log_channel"))
        log_channel = interaction.guild.get_channel(log_id) if log_id else None
        embed = make_embed("🎫 Ticket encerrado", color=COLOR_INFO)
        embed.add_field(name="Autor", value=f"<@{ticket['user_id']}>")
        embed.add_field(name="Tipo", value=ticket["category"] or "—")
        embed.add_field(name="Assumido por", value=f"<@{ticket['claimed_by']}>" if ticket["claimed_by"] else "—")
        embed.add_field(name="Encerrado por", value=interaction.user.mention)
        if isinstance(log_channel, discord.TextChannel):
            await log_channel.send(embed=embed, file=discord.File(transcript, filename))
        else:
            await interaction.followup.send(
                "⚠️ Nenhum canal de logs configurado; segue a transcrição só para você.",
                file=discord.File(transcript, filename), ephemeral=True)

        await channel.send("🔒 Atendimento encerrado. Este canal será removido em 5 segundos.")
        await asyncio.sleep(5)
        await channel.delete(reason=f"Ticket encerrado por {interaction.user}")


class TicketPanelView(discord.ui.View):
    def __init__(self, categories: list[str] | None = None):
        super().__init__(timeout=None)
        cats = categories or ["Suporte"]
        self.select = discord.ui.Select(
            placeholder="Escolha o tipo de atendimento",
            custom_id="ticket:open",
            options=[discord.SelectOption(label=c[:100], value=c[:100]) for c in cats[:25]],
        )
        self.select.callback = self.on_select
        self.add_item(self.select)

    async def on_select(self, interaction: discord.Interaction):
        bot = interaction.client
        guild, user = interaction.guild, interaction.user
        tipo = self.select.values[0]

        if not await bot.module_enabled(guild.id, "tickets"):
            return await interaction.response.send_message("Tickets desativados.", ephemeral=True)

        existing = await bot.db.get_open_ticket(guild.id, user.id)
        if existing:
            ch = guild.get_channel(existing["channel_id"])
            if ch:
                return await interaction.response.send_message(
                    f"Você já tem um ticket aberto: {ch.mention}", ephemeral=True)
            await bot.db.close_ticket(existing["id"], bot.user.id)  # canal foi apagado manualmente

        cat_id = await bot.db.get_int(guild.id, "ticket_category")
        category = guild.get_channel(cat_id) if cat_id else None
        role_id = await bot.db.get_int(guild.id, "ticket_role")
        role = guild.get_role(role_id) if role_id else None

        view_perms = discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                 attach_files=True, read_message_history=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: view_perms,
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                  manage_channels=True, embed_links=True,
                                                  attach_files=True, read_message_history=True),
        }
        if role:
            overwrites[role] = view_perms

        slug = re.sub(r"[^a-z0-9\-]", "", user.name.lower()) or "usuario"
        try:
            channel = await guild.create_text_channel(
                f"ticket-{slug}"[:90],
                category=category if isinstance(category, discord.CategoryChannel) else None,
                overwrites=overwrites, topic=f"Ticket de {user} ({user.id}) · {tipo}",
                reason=f"Ticket aberto por {user}",
            )
        except discord.Forbidden:
            return await interaction.response.send_message(
                "❌ Não tenho permissão para criar canais. Avise a equipe.", ephemeral=True)

        await bot.db.create_ticket(guild.id, channel.id, user.id, tipo)
        embed = make_embed(f"🎫 {tipo}",
                           f"Olá, {user.mention}! Descreva seu problema e aguarde a equipe.\n"
                           "Use os botões abaixo para assumir ou encerrar o atendimento.")
        ping = role.mention if role else ""
        await channel.send(content=ping, embed=embed, view=TicketControlView(),
                           allowed_mentions=discord.AllowedMentions(roles=True))
        await interaction.response.send_message(f"✅ Ticket criado: {channel.mention}", ephemeral=True)
        try:  # reseta a seleção do menu
            await interaction.message.edit(view=self)
        except discord.HTTPException:
            pass


class Tickets(commands.Cog):
    ticket = app_commands.Group(name="ticket", description="Sistema de tickets", guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(TicketPanelView())
        self.bot.add_view(TicketControlView())

    @ticket.command(name="painel", description="Publica o painel de tickets")
    @app_commands.describe(canal="Canal do painel (padrão: o atual)")
    @guild_perm(manage_guild=True)
    async def painel(self, interaction: discord.Interaction, canal: discord.TextChannel | None = None):
        canal = canal or interaction.channel
        cats = (await self.bot.db.get_setting(interaction.guild_id, "ticket_categories")).split(",")
        cats = [c.strip() for c in cats if c.strip()]
        embed = make_embed("🎫 Central de atendimento",
                           "Selecione abaixo o tipo de atendimento para abrir um ticket privado.")
        await canal.send(embed=embed, view=TicketPanelView(cats))
        await interaction.response.send_message("✅ Painel publicado.", ephemeral=True)

    async def _member_change(self, interaction, membro: discord.Member, add: bool):
        t = await self.bot.db.get_ticket_by_channel(interaction.channel_id)
        if not t:
            return await interaction.response.send_message("Use dentro de um ticket.", ephemeral=True)
        if not await is_staff(self.bot, interaction.user):
            return await interaction.response.send_message("❌ Apenas a equipe.", ephemeral=True)
        if add:
            await interaction.channel.set_permissions(membro, view_channel=True, send_messages=True,
                                                      read_message_history=True)
        else:
            await interaction.channel.set_permissions(membro, overwrite=None)
        await interaction.response.send_message(
            f"✅ {membro.mention} {'adicionado ao' if add else 'removido do'} ticket.",
            allowed_mentions=discord.AllowedMentions.none())

    @ticket.command(name="adicionar", description="Adiciona um membro ao ticket atual")
    async def adicionar(self, interaction: discord.Interaction, membro: discord.Member):
        await self._member_change(interaction, membro, True)

    @ticket.command(name="remover", description="Remove um membro do ticket atual")
    async def remover(self, interaction: discord.Interaction, membro: discord.Member):
        await self._member_change(interaction, membro, False)


async def setup(bot):
    await bot.add_cog(Tickets(bot))
