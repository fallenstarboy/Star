"""Boas-vindas, cargo automático e verificação por botão."""
import logging

import discord
from discord import app_commands
from discord.ext import commands

from utils import COLOR_OK, guild_perm, make_embed

log = logging.getLogger("bot.welcome")


class VerifyView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Verificar", emoji="✅", style=discord.ButtonStyle.success,
                       custom_id="verify:button")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot = interaction.client
        role_id = await bot.db.get_int(interaction.guild_id, "verified_role")
        role = interaction.guild.get_role(role_id) if role_id else None
        if not role:
            return await interaction.response.send_message(
                "❌ A verificação não está configurada. Avise a equipe.", ephemeral=True)
        if role in interaction.user.roles:
            return await interaction.response.send_message("Você já está verificado(a)!", ephemeral=True)
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message(
                "❌ Não consigo atribuir esse cargo. Avise a equipe.", ephemeral=True)
        await interaction.user.add_roles(role, reason="Verificação por botão")
        auto_id = await bot.db.get_int(interaction.guild_id, "autorole")
        auto = interaction.guild.get_role(auto_id) if auto_id else None
        if auto and auto in interaction.user.roles and auto < interaction.guild.me.top_role:
            await interaction.user.remove_roles(auto, reason="Verificação concluída")
        await interaction.response.send_message("✅ Verificação concluída. Bem-vindo(a)!", ephemeral=True)


class Welcome(commands.Cog):
    verificacao = app_commands.Group(name="verificacao", description="Verificação de novos membros",
                                     guild_only=True)

    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(VerifyView())

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild = member.guild
        if member.bot or not await self.bot.module_enabled(guild.id, "welcome"):
            return
        db = self.bot.db
        role_id = await db.get_int(guild.id, "autorole")
        role = guild.get_role(role_id) if role_id else None
        if role and role < guild.me.top_role and guild.me.guild_permissions.manage_roles:
            try:
                await member.add_roles(role, reason="Cargo automático")
            except discord.HTTPException:
                log.warning("Falha ao dar cargo automático em %s", guild.id)

        channel_id = await db.get_int(guild.id, "welcome_channel")
        channel = guild.get_channel(channel_id) if channel_id else None
        if isinstance(channel, discord.TextChannel):
            text = await db.get_setting(guild.id, "welcome_message")
            text = (text.replace("{user}", member.mention)
                        .replace("{username}", member.display_name)
                        .replace("{server}", guild.name)
                        .replace("{count}", str(guild.member_count)))
            try:
                await channel.send(
                    embed=make_embed("👋 Novo membro!", text, COLOR_OK),
                    allowed_mentions=discord.AllowedMentions(users=[member]),
                )
            except discord.HTTPException:
                pass

    @verificacao.command(name="painel", description="Publica o painel de verificação")
    @app_commands.describe(canal="Canal do painel (padrão: o atual)")
    @guild_perm(manage_guild=True)
    async def painel(self, interaction: discord.Interaction, canal: discord.TextChannel | None = None):
        if not await self.bot.db.get_int(interaction.guild_id, "verified_role"):
            return await interaction.response.send_message(
                "❌ Defina antes o cargo com `/config cargo_verificado`.", ephemeral=True)
        canal = canal or interaction.channel
        embed = make_embed(
            "✅ Verificação",
            "Clique no botão abaixo para liberar o acesso ao servidor.\n"
            "Nunca pedimos senhas, tokens ou dados pessoais.",
        )
        await canal.send(embed=embed, view=VerifyView())
        await interaction.response.send_message("✅ Painel publicado.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Welcome(bot))
