"""Painel de configuração por servidor (/config ...)."""
import discord
from discord import app_commands
from discord.ext import commands

from utils import COLOR_INFO, make_embed

MODULES = [
    app_commands.Choice(name="Moderação", value="moderation"),
    app_commands.Choice(name="Automod", value="automod"),
    app_commands.Choice(name="Boas-vindas", value="welcome"),
    app_commands.Choice(name="Tickets", value="tickets"),
]


def _chan(v):
    return f"<#{v}>" if v else "—"


def _role(v):
    return f"<@&{v}>" if v else "—"


def _flag(v):
    return "✅ ativo" if v == "1" else "⛔ desativado"


@app_commands.guild_only()
@app_commands.default_permissions(manage_guild=True)
class Config(commands.GroupCog, name="config", description="Configurações do bot neste servidor"):
    def __init__(self, bot):
        self.bot = bot

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.user.guild_permissions.manage_guild:
            raise app_commands.MissingPermissions(["manage_guild"])
        return True

    async def _set(self, interaction, key, value, label):
        await self.bot.update_setting(interaction.guild_id, interaction.user.id, key, str(value))
        await interaction.response.send_message(f"✅ {label} atualizado.", ephemeral=True)

    @app_commands.command(name="ver", description="Mostra a configuração atual")
    async def ver(self, interaction: discord.Interaction):
        s = await self.bot.db.all_settings(interaction.guild_id)
        e = make_embed("⚙️ Configuração do servidor", color=COLOR_INFO)
        e.add_field(
            name="Módulos",
            value="\n".join(
                f"{n}: {_flag(s[f'module.{k}'])}"
                for n, k in [("Moderação", "moderation"), ("Automod", "automod"),
                             ("Boas-vindas", "welcome"), ("Tickets", "tickets")]
            ),
            inline=False,
        )
        e.add_field(name="Logs", value=_chan(s.get("log_channel")))
        e.add_field(name="Boas-vindas", value=_chan(s.get("welcome_channel")))
        e.add_field(name="Cargo automático", value=_role(s.get("autorole")))
        e.add_field(name="Cargo verificado", value=_role(s.get("verified_role")))
        e.add_field(name="Categoria de tickets", value=_chan(s.get("ticket_category")))
        e.add_field(name="Cargo de suporte", value=_role(s.get("ticket_role")))
        e.add_field(name="Logs de tickets", value=_chan(s.get("ticket_log_channel")))
        e.add_field(
            name="Automod",
            value=(
                f"Spam: {s['spam_limit']} msgs/{s['spam_window']}s\n"
                f"Menções máx.: {s['mention_limit']}\n"
                f"Bloquear links: {'sim' if s['block_links'] == '1' else 'não'}\n"
                f"Domínios permitidos: {s['allowed_domains'] or '—'}\n"
                f"Raid: {s['raid_limit']} entradas/{s['raid_window']}s "
                f"(timeout: {'sim' if s['raid_timeout'] == '1' else 'não'})"
            ),
            inline=False,
        )
        await interaction.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="logs", description="Define o canal de logs de moderação")
    async def logs(self, interaction: discord.Interaction, canal: discord.TextChannel):
        perms = canal.permissions_for(interaction.guild.me)
        if not (perms.send_messages and perms.embed_links):
            return await interaction.response.send_message(
                "❌ Não consigo enviar embeds nesse canal.", ephemeral=True)
        await self._set(interaction, "log_channel", canal.id, "Canal de logs")

    @app_commands.command(name="modulo", description="Ativa ou desativa um módulo")
    @app_commands.choices(modulo=MODULES)
    async def modulo(self, interaction: discord.Interaction, modulo: app_commands.Choice[str], ativo: bool):
        await self._set(interaction, f"module.{modulo.value}", "1" if ativo else "0",
                        f"Módulo {modulo.name}")

    @app_commands.command(name="boasvindas", description="Configura as mensagens de boas-vindas")
    @app_commands.describe(
        canal="Canal das boas-vindas",
        mensagem="Use {user}, {username}, {server} e {count}",
    )
    async def boasvindas(self, interaction: discord.Interaction,
                         canal: discord.TextChannel | None = None, mensagem: str | None = None):
        if not canal and not mensagem:
            return await interaction.response.send_message(
                "Informe ao menos o canal ou a mensagem.", ephemeral=True)
        if canal:
            await self.bot.update_setting(interaction.guild_id, interaction.user.id,
                                          "welcome_channel", str(canal.id))
        if mensagem:
            await self.bot.update_setting(interaction.guild_id, interaction.user.id,
                                          "welcome_message", mensagem[:1500])
        await interaction.response.send_message("✅ Boas-vindas atualizadas.", ephemeral=True)

    async def _check_role(self, interaction, cargo: discord.Role) -> bool:
        if cargo.managed or cargo.is_default() or cargo >= interaction.guild.me.top_role:
            await interaction.response.send_message(
                "❌ Não consigo atribuir esse cargo (gerenciado ou acima do meu).", ephemeral=True)
            return False
        return True

    @app_commands.command(name="cargo_automatico", description="Cargo dado a todo novo membro")
    async def cargo_automatico(self, interaction: discord.Interaction, cargo: discord.Role):
        if await self._check_role(interaction, cargo):
            await self._set(interaction, "autorole", cargo.id, "Cargo automático")

    @app_commands.command(name="cargo_verificado", description="Cargo dado após a verificação")
    async def cargo_verificado(self, interaction: discord.Interaction, cargo: discord.Role):
        if await self._check_role(interaction, cargo):
            await self._set(interaction, "verified_role", cargo.id, "Cargo verificado")

    @app_commands.command(name="tickets", description="Configura o sistema de tickets")
    @app_commands.describe(
        categoria="Categoria onde os tickets serão criados",
        cargo_suporte="Cargo que atende os tickets",
        canal_logs="Canal PRIVADO para transcrições",
        tipos="Tipos separados por vírgula (máx. 25)",
    )
    async def tickets(self, interaction: discord.Interaction,
                      categoria: discord.CategoryChannel | None = None,
                      cargo_suporte: discord.Role | None = None,
                      canal_logs: discord.TextChannel | None = None,
                      tipos: str | None = None):
        uid, gid = interaction.user.id, interaction.guild_id
        if categoria:
            await self.bot.update_setting(gid, uid, "ticket_category", str(categoria.id))
        if cargo_suporte:
            await self.bot.update_setting(gid, uid, "ticket_role", str(cargo_suporte.id))
        if canal_logs:
            await self.bot.update_setting(gid, uid, "ticket_log_channel", str(canal_logs.id))
        if tipos:
            lista = [t.strip() for t in tipos.split(",") if t.strip()][:25]
            await self.bot.update_setting(gid, uid, "ticket_categories", ",".join(lista))
        await interaction.response.send_message(
            "✅ Tickets atualizados. Use `/ticket painel` para publicar o painel.", ephemeral=True)

    @app_commands.command(name="automod", description="Ajusta as regras automáticas")
    @app_commands.describe(
        spam_mensagens="Mensagens permitidas na janela de spam",
        spam_segundos="Tamanho da janela de spam (segundos)",
        mencoes_max="Máximo de menções por mensagem",
        bloquear_links="Bloquear links (exceto domínios permitidos)",
        dominios_permitidos="Domínios separados por vírgula (ex.: youtube.com,github.com)",
        raid_entradas="Entradas na janela que disparam o alerta de raid",
        raid_segundos="Janela de detecção de raid (segundos)",
        raid_timeout="Aplicar timeout de 10min em quem entrar durante um raid",
    )
    async def automod(self, interaction: discord.Interaction,
                      spam_mensagens: app_commands.Range[int, 2, 20] | None = None,
                      spam_segundos: app_commands.Range[int, 2, 30] | None = None,
                      mencoes_max: app_commands.Range[int, 2, 30] | None = None,
                      bloquear_links: bool | None = None,
                      dominios_permitidos: str | None = None,
                      raid_entradas: app_commands.Range[int, 3, 50] | None = None,
                      raid_segundos: app_commands.Range[int, 5, 120] | None = None,
                      raid_timeout: bool | None = None):
        changes = {
            "spam_limit": spam_mensagens, "spam_window": spam_segundos,
            "mention_limit": mencoes_max,
            "block_links": None if bloquear_links is None else int(bloquear_links),
            "allowed_domains": None if dominios_permitidos is None
            else ",".join(d.strip().lower() for d in dominios_permitidos.split(",") if d.strip()),
            "raid_limit": raid_entradas, "raid_window": raid_segundos,
            "raid_timeout": None if raid_timeout is None else int(raid_timeout),
        }
        changes = {k: v for k, v in changes.items() if v is not None}
        if not changes:
            return await interaction.response.send_message("Nenhum valor informado.", ephemeral=True)
        for key, value in changes.items():
            await self.bot.update_setting(interaction.guild_id, interaction.user.id, key, str(value))
        await interaction.response.send_message("✅ Automod atualizado.", ephemeral=True)

    @app_commands.command(name="historico", description="Últimas alterações de configuração")
    async def historico(self, interaction: discord.Interaction):
        rows = await self.bot.db.get_history(interaction.guild_id, 10)
        if not rows:
            return await interaction.response.send_message("Nenhuma alteração registrada.", ephemeral=True)
        lines = [
            f"`{r['created_at'][:16].replace('T', ' ')}` <@{r['user_id']}> · **{r['key']}** → "
            f"`{(r['new_value'] or '')[:40]}`"
            for r in rows
        ]
        await interaction.response.send_message(
            embed=make_embed("📜 Histórico de configuração", "\n".join(lines)), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Config(bot))
