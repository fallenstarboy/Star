"""Regras automáticas: spam, excesso de menções, links e proteção contra raids."""
import collections
import re
import time

import discord
from discord.ext import commands

import datetime as dt
from utils import COLOR_BAD, make_embed, record_case

URL_RE = re.compile(r"(?:https?://|www\.|discord\.gg/)[^\s<>]+", re.I)


class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.messages: dict[tuple[int, int], collections.deque] = {}
        self.joins: dict[int, collections.deque] = {}
        self.raid_until: dict[int, float] = {}

    # ---------- mensagens ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild or not isinstance(message.author, discord.Member):
            return
        guild, member = message.guild, message.author
        if not await self.bot.module_enabled(guild.id, "automod"):
            return
        perms = member.guild_permissions
        if perms.administrator or perms.manage_messages:
            return  # equipe é isenta

        db = self.bot.db
        # 1) Flood / spam
        limit = int(await db.get_setting(guild.id, "spam_limit"))
        window = int(await db.get_setting(guild.id, "spam_window"))
        key = (guild.id, member.id)
        q = self.messages.setdefault(key, collections.deque(maxlen=50))
        nowt = time.monotonic()
        q.append(nowt)
        while q and nowt - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            q.clear()
            return await self._punish(message, "Spam/flood", timeout_min=5)

        # 2) Excesso de menções
        mention_limit = int(await db.get_setting(guild.id, "mention_limit"))
        mentions = len(set(message.mentions)) + len(set(message.role_mentions))
        if message.mention_everyone:
            mentions += 1
        if mentions >= mention_limit:
            return await self._punish(message, "Excesso de menções", timeout_min=10)

        # 3) Links não autorizados
        if await db.get_setting(guild.id, "block_links") == "1":
            allowed = [d for d in (await db.get_setting(guild.id, "allowed_domains")).split(",") if d]
            for url in URL_RE.findall(message.content):
                host = re.sub(r"^(https?://)?(www\.)?", "", url, flags=re.I).split("/")[0].lower()
                if not any(host == d or host.endswith("." + d) for d in allowed):
                    return await self._punish(message, "Link não autorizado")

    async def _punish(self, message: discord.Message, reason: str, timeout_min: int | None = None):
        guild, member = message.guild, message.author
        me = guild.me
        try:
            if message.channel.permissions_for(me).manage_messages:
                await message.delete()
        except discord.HTTPException:
            pass
        timed_out = False
        if (timeout_min and me.guild_permissions.moderate_members
                and member.top_role < me.top_role and member.id != guild.owner_id):
            try:
                await member.timeout(dt.timedelta(minutes=timeout_min), reason=f"Automod: {reason}")
                timed_out = True
            except discord.HTTPException:
                pass
        try:
            await message.channel.send(
                f"⚠️ {member.mention}, sua mensagem foi removida: **{reason}**.", delete_after=6)
        except discord.HTTPException:
            pass
        extra = f"Canal: {message.channel.mention}" + (f"\nTimeout: {timeout_min} min" if timed_out else "")
        await record_case(self.bot, guild, member, me, f"Automod · {reason}", reason, extra)

    # ---------- raids ----------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild = member.guild
        if member.bot or not await self.bot.module_enabled(guild.id, "automod"):
            return
        limit = int(await self.bot.db.get_setting(guild.id, "raid_limit"))
        window = int(await self.bot.db.get_setting(guild.id, "raid_window"))
        q = self.joins.setdefault(guild.id, collections.deque(maxlen=100))
        nowt = time.monotonic()
        q.append(nowt)
        while q and nowt - q[0] > window:
            q.popleft()

        if len(q) >= limit and nowt > self.raid_until.get(guild.id, 0):
            self.raid_until[guild.id] = nowt + 300  # modo raid por 5 minutos
            e = make_embed("🚨 Possível raid detectado", color=COLOR_BAD)
            e.description = f"{len(q)} entradas em {window}s. Modo de proteção ativo por 5 minutos."
            await self.bot.send_log(guild, e)

        if nowt < self.raid_until.get(guild.id, 0):
            if (await self.bot.db.get_setting(guild.id, "raid_timeout") == "1"
                    and guild.me.guild_permissions.moderate_members):
                try:
                    await member.timeout(dt.timedelta(minutes=10), reason="Automod: proteção contra raid")
                    await record_case(self.bot, guild, member, guild.me, "Automod · Raid",
                                      "Entrada durante raid", "Timeout: 10 min")
                except discord.HTTPException:
                    pass


async def setup(bot):
    await bot.add_cog(AutoMod(bot))
